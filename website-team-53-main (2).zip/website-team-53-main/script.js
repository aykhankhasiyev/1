var logo = document.getElementById("ada_logo");
logo.onclick = function(a, b){
    document.location.href="/index.html";
}
document.addEventListener('DOMContentLoaded', function () {
    
    var codeAcademyElements = document.querySelectorAll('.codeacademy');

    
    codeAcademyElements.forEach(function (element) {
        element.addEventListener('mouseenter', function () {
            
            element.style.backgroundColor = '#e0e0e0';
        });

        element.addEventListener('mouseleave', function () {
            
            element.style.backgroundColor = '';
        });
    });
});
